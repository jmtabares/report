function getWorkstreams() {
	return Object.keys(getJSONData());
}

function getChartData(workstream) {
	var result = [];
	var data = getJSONData(workstream);
	var numberOfScenarios = Object.keys(data).length;
	var numberOfAutomated = data.filter((obj) => obj.status === "automated").length;
	result.push(numberOfAutomated,(numberOfScenarios-numberOfAutomated),0);
	return result;
}
	
function getStats(workstream) {
	var data = getJSONData(workstream);
	var numberOfScenarios = Object.keys(data).length;
	var numberOfAutomated = data.filter((obj) => obj.status === "automated").length;
	var percentage = Math.trunc(numberOfAutomated * 100 / numberOfScenarios);
	result = numberOfScenarios + ' scenarios  (' + percentage + '% Automated )';
	
	document.getElementById("stats-"+workstream).style.textDecoration = "none";
	document.getElementById("stats-"+workstream).innerHTML = result;
}

function getTableAndChartData(workstream) {
	var $table = $('#table-'+workstream);

	var tableData = getJSONData(workstream);
	var chartData = getChartData(workstream);
	
	$(function () {
		$('#table-'+workstream).bootstrapTable({
			data: tableData
		});
	});
	var options = {
	  type: 'doughnut',
	  data: {
		labels: ['Automated', 'Pending', 'Out of scope'],
		datasets: [{
		  label: 'Scenarios',
		  backgroundColor: ['#3cba9f', '#c45850', '#e8c3b9'],
		  data: chartData
		}]
	  },
	  options: {
	  }
	};
	new Chart(document.getElementById('chart-tests-'+workstream), options);
	getStats(workstream);
}

function statusFormatter(value, row) {
	return '<span class="'+value+'">'+value+'</span>';
};

function cellStyle(value, row, index, field) {
	return {classes: value ? value : 'pending'};
};
