function getJSONData(workstream) {
	var result;
	var jsonData = {
		"accountManagement":
		[
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_001", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_002", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_003", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_004", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_005", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_006", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_007", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_008", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_009", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_010", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_011", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_012", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_013", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_014", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_015", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5351", "jira": "GBP-6046", "acceptance-criteria": "GBP-6046_016", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5349", "jira": "GBP-6127", "acceptance-criteria": "GBP-6127_001", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5349", "jira": "GBP-6127", "acceptance-criteria": "GBP-6127_002", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5349", "jira": "GBP-6127", "acceptance-criteria": "GBP-6127_003", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5349", "jira": "GBP-6127", "acceptance-criteria": "GBP-6127_004", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5349", "jira": "GBP-6127", "acceptance-criteria": "GBP-6127_005", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5349", "jira": "GBP-6127", "acceptance-criteria": "GBP-6127_006", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5349", "jira": "GBP-6127", "acceptance-criteria": "GBP-6127_007", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5349", "jira": "GBP-6127", "acceptance-criteria": "GBP-6127_008", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5349", "jira": "GBP-6127", "acceptance-criteria": "GBP-6127_009", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5350", "jira": "GBP-6049", "acceptance-criteria": "GBP-6049_001", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5350", "jira": "GBP-6049", "acceptance-criteria": "GBP-6049_002", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5350", "jira": "GBP-6049", "acceptance-criteria": "GBP-6049_003", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5350", "jira": "GBP-6049", "acceptance-criteria": "GBP-6049_004", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5350", "jira": "GBP-6049", "acceptance-criteria": "GBP-6049_005", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5350", "jira": "GBP-6049", "acceptance-criteria": "GBP-6049_006", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5350", "jira": "GBP-6049", "acceptance-criteria": "GBP-6049_007", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5350", "jira": "GBP-6049", "acceptance-criteria": "GBP-6049_008", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5350", "jira": "GBP-6049", "acceptance-criteria": "GBP-6049_009", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_001", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_002", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_003", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_004", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_005", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_006", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_007", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_008", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_009", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_010", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_011", "description": "Description", "status": "pending", "execution-status": "pending" },
			{ "epic":"GBP-5356", "jira": "GBP-6162", "acceptance-criteria": "GBP-6162_012", "description": "Description", "status": "pending", "execution-status": "pending" }
		],
		"postings": [
			{ "epic": "GBP-404", "jira": "GBP-493", "acceptance-criteria": "AC-1", "description": "Base path and resource path defined", "status": "automated", "execution-status": "passed" },
			{ "epic": "GBP-404", "jira": "GBP-493", "acceptance-criteria": "AC-2", "description": "Swagger deployed successfully to dev and available to be shared to consumers", "status": "automated", "execution-status": "passed" },
			{ "epic": "GBP-404", "jira": "GBP-824", "acceptance-criteria": "AC-1", "description": "Able to post the instruction into vault", "status": "pending", "execution-status": "pending" },
			{ "epic": "GBP-404", "jira": "GBP-509", "acceptance-criteria": "AC-1", "description": "Error 409 when duplicate request id sent for a committed transaction", "status": "pending","execution-status": "pending" },
			{ "epic": "GBP-404", "jira": "GBP-509", "acceptance-criteria": "AC-2", "description": "Posting request correct although duplicate request id for a non-committed transaction", "status": "pending", "execution-status": "pending" },
			{ "epic": "GBP-404", "jira": "GBP-509", "acceptance-criteria": "AC-3", "description": "Error when duplicate request id sent for unknown state for the original transaction", "status": "pending", "execution-status": "pending" }
		]
	};
	
 	return workstream ? jsonData[workstream] : jsonData;
}
